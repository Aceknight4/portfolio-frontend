import React from 'react';
import './ProjectCard.css';

// This is the "shape" of a project. TypeScript will now warn you if
// you ever try to use a project object that's missing one of these
// fields, or has the wrong type — that's the main benefit of TS over
// plain JS: mistakes show up while you're typing, not when the page
// crashes in the browser.
export interface Project {
  id: number | string;
  index: string;       // e.g. "01" — just a display label, not a real DB index
  title: string;
  description: string;
  tags: string[];
}

interface ProjectCardProps {
  project: Project;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project }) => {
  return (
    <div className="project-card">
      <span className="project-card__index">{project.index}</span>
      <h3 className="project-card__title">{project.title}</h3>
      <p className="project-card__desc">{project.description}</p>
      <div className="project-card__stack">
        {project.tags.map((tag) => (
          <span className="chip" key={tag}>{tag}</span>
        ))}
      </div>
    </div>
  );
};

export default ProjectCard;
