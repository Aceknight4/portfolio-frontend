import React from 'react';
import ProjectCard, { Project } from '../components/ProjectCard';
import './Home.css';

// TODO — connect to your real data
// -----------------------------------------------------------------
// Your terminal logs show you already have working endpoints:
//   GET /api/profile/
//   GET /api/projects/?featured=true
//
// Right now this array is static so the page works immediately.
// When you're ready, replace it with a fetch, e.g.:
//
//   const [projects, setProjects] = useState<Project[]>([]);
//   useEffect(() => {
//     api.get('/api/projects/?featured=true').then((res) => {
//       setProjects(res.data);
//     });
//   }, []);
//
// and use `projects` instead of `featuredProjects` in the JSX below.
// You'll just need to make sure the fields returned by your Django
// serializer match the Project interface (id, index, title,
// description, tags) — or map the response into that shape.
// -----------------------------------------------------------------
const featuredProjects: Project[] = [
  {
    id: 1,
    index: '01',
    title: 'SOC Automation System',
    description:
      'Suricata-driven detection with Isolation Forest and Random Forest models, automated triage and reporting.',
    tags: ['python', 'ml'],
  },
  {
    id: 2,
    index: '02',
    title: 'SentinelLite',
    description:
      'A productized SOC dashboard — Flask, Dockerized, built for small security teams.',
    tags: ['flask', 'docker'],
  },
  {
    id: 3,
    index: '03',
    title: 'Risk Mitigation Framework',
    description:
      'A security assessment framework pairing technical review with stakeholder analysis.',
    tags: ['strategy'],
  },
];

interface SkillRow {
  label: string;
  description: string;
}

const skills: SkillRow[] = [
  { label: 'Python / Django', description: 'APIs, auth, data modelling — the backend of every project I ship.' },
  { label: 'React / TypeScript', description: 'Interfaces that are fast, typed and maintainable.' },
  { label: 'Network security', description: 'Suricata, Wireshark, threat detection and response.' },
  { label: 'Docker / Linux', description: 'Deployment, systemd scheduling, production hygiene.' },
];

const Home: React.FC = () => {
  return (
    <>
      <section className="hero">
        <div className="hero__inner">
          <span className="eyebrow">Full-stack developer · Security engineer</span>
          <h1 className="hero__title">
            Seppo Anel builds <em>secure</em>, well-made software.
          </h1>
          <p className="hero__sub">
            Django and React/TypeScript on the surface, a network security
            background underneath — I build products that hold up under scrutiny.
          </p>
          <div className="hero__row">
            <div className="hero__actions">
              <a href="/projects" className="btn btn--primary">View projects</a>
              <a href="/resume.pdf" className="btn btn--secondary">Download résumé</a>
            </div>
            <div className="hero__facts">
              Buea, Cameroon<br />
              B.Tech, Network &amp; Security<br />
              Open to remote &amp; relocation
            </div>
          </div>
        </div>

        <svg className="hero__blueprint" viewBox="0 0 400 400" aria-hidden="true">
          <g stroke="#0B5D6B" strokeWidth={1} fill="none">
            <circle cx="300" cy="90" r="4" />
            <circle cx="340" cy="180" r="4" />
            <circle cx="260" cy="220" r="4" />
            <circle cx="330" cy="290" r="4" />
            <line x1="300" y1="90" x2="340" y2="180" />
            <line x1="340" y1="180" x2="260" y2="220" />
            <line x1="260" y1="220" x2="330" y2="290" />
            <rect x="240" y="60" width="140" height="260" strokeDasharray="2 4" />
          </g>
        </svg>
      </section>

      <section className="section">
        <div className="section-head">
          <div>
            <span className="eyebrow">Featured work</span>
            <h2>Selected projects</h2>
          </div>
          <a href="/projects" className="section-link">view all</a>
        </div>
        <div className="projects-grid">
          {featuredProjects.map((project) => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      </section>

      <section className="section" style={{ paddingTop: 0 }}>
        <div className="section-head">
          <div>
            <span className="eyebrow">Capabilities</span>
            <h2>Stack &amp; strength</h2>
          </div>
        </div>
        <div className="skills-table">
          {skills.map((skill) => (
            <div className="skill-row" key={skill.label}>
              <span className="skill-row__label">{skill.label}</span>
              <span className="skill-row__desc">{skill.description}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="contact">
        <span className="eyebrow eyebrow--light">Get in touch</span>
        <h2>
          Have a system worth <em>securing</em>?
        </h2>
        <p>Open to freelance contracts and full-time roles — remote or relocation.</p>
        <a href="/contact" className="btn btn--accent">Start a conversation</a>
      </section>
    </>
  );
};

export default Home;
