# Blueprint theme — integration guide

You know nothing about frontend yet, so here's the exact, no-guessing version.

## 1. Add the Google Fonts

Open `public/index.html` in your project and paste this inside the `<head>`,
anywhere above `</head>`:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
```

## 2. Copy the files in

Copy each file below into the matching folder in your project
(`src/components`, `src/pages`), overwriting the old ones:

```
src/
  components/
    Navbar.tsx        ← replace
    Navbar.css         ← new
    Footer.tsx         ← replace
    Footer.css          ← new
    ProjectCard.tsx    ← replace
    ProjectCard.css     ← new
  pages/
    Home.tsx           ← replace
    Home.css            ← new
  styles/
    theme.css            ← new
```

## 3. Import the theme

Open `src/index.css` and add this as the very first line:

```css
@import './styles/theme.css';
```

That's it — every component below reads its colors and fonts from
`theme.css`, so this one line is what actually turns the whole site teal
and serif instead of your old navy/cyan.

## 4. Check two things that might not match your project

- **Routing**: `Navbar.tsx` uses `<Link to="/projects">` from
  `react-router-dom`. If your app uses different route paths, update
  the `to="..."` values to match your actual routes in `App.tsx`.
- **`ProjectCard`'s `Project` type**: I don't have your real API
  response shape, so I guessed reasonable field names
  (`id`, `index`, `title`, `description`, `tags`). If your Django
  serializer returns different field names, either rename them to
  match, or map the API response into this shape before passing it in.

## 5. Run it

```
npm start
```

If something looks broken, it's almost always one of:
- the font `<link>` tags missing from `public/index.html`
- `@import './styles/theme.css';` missing or not the first line
- a typo in a `className` (React is case-sensitive, CSS class names
  must match exactly between the `.tsx` and `.css` file)

## 6. Next steps

Right now `Home.tsx` uses hardcoded project/skill data so it works
immediately. There's a `TODO` comment near the top of that file
showing exactly how to swap it for a real fetch from your
`/api/projects/?featured=true` endpoint once you're ready. Ping me
when you get there and I'll help you wire it up against your actual
`api.ts`.

The other pages (`Projects.tsx`, `Skills.tsx`, `Experience.tsx`,
`Contact.tsx`, `Login.tsx`) still use your old styling — they'll look
inconsistent with the new Home page until we redesign them too. Say
the word and we'll go section by section.
