import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

// NOTE: this assumes you're using react-router-dom for navigation
// (your file list has Login.tsx / ProtectedRoute.tsx, so you likely
// already are). If your routes use different paths than the ones
// below, just update the `to="..."` values to match.

const Navbar: React.FC = () => {
  return (
    <nav className="navbar">
      <Link to="/" className="navbar__logo">AnelGraph</Link>
      <div className="navbar__links">
        <Link to="/projects">Projects</Link>
        <Link to="/skills">Skills</Link>
        <Link to="/experience">Experience</Link>
        <Link to="/contact">Contact</Link>
      </div>
      <Link to="/contact" className="navbar__cta">Contact</Link>
    </nav>
  );
};

export default Navbar;
